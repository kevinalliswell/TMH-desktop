"""Pure domain-layer components."""

