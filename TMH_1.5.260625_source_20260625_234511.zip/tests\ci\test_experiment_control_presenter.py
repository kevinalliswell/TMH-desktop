from __future__ import annotations

import logging
from types import SimpleNamespace

from src.ui.presenters.experiment_control_presenter import ExperimentControlPresenter


class FakeExperimentApi:
    def __init__(self):
        self.tare_called = False
        self.manual_initial_weight_called = False
        self.controller = object()

    def tare_balance(self, parent_widget=None, skip_confirmation=False) -> bool:
        self.tare_called = True
        return True

    def manual_set_initial_weight(self, parent_widget=None) -> bool:
        self.manual_initial_weight_called = True
        return True

    def get_controller(self):
        return self.controller


class FakeView:
    def __init__(self, *, ensure_result: bool = True):
        self.ensure_result = ensure_result
        self.ensure_calls = 0
        self.status_messages: list[str] = []
        self.warnings: list[tuple[str, str]] = []
        self.errors: list[tuple[str, str]] = []

    def ensure_experiment_controller_ready(self) -> bool:
        self.ensure_calls += 1
        return self.ensure_result

    def dialog_parent(self):
        return None

    def set_status_message(self, message: str) -> None:
        self.status_messages.append(message)

    def show_warning(self, title: str, message: str) -> None:
        self.warnings.append((title, message))

    def show_error(self, title: str, message: str) -> None:
        self.errors.append((title, message))


def _presenter(view: FakeView, api: FakeExperimentApi) -> ExperimentControlPresenter:
    return ExperimentControlPresenter(
        view=view,
        experiment_api=api,
        workflow_service=SimpleNamespace(device_manager=object()),
        logger=logging.getLogger("test.presenter"),
    )


def test_tare_balance_prepares_controller_before_device_command() -> None:
    view = FakeView()
    api = FakeExperimentApi()

    _presenter(view, api).handle_tare_balance()

    assert view.ensure_calls == 1
    assert api.tare_called is True
    assert view.status_messages[-1] == "天平清零成功"


def test_tare_balance_stops_when_controller_preparation_fails() -> None:
    view = FakeView(ensure_result=False)
    api = FakeExperimentApi()

    _presenter(view, api).handle_tare_balance()

    assert view.ensure_calls == 1
    assert api.tare_called is False


def test_initial_weight_prepares_controller_before_manual_flow() -> None:
    view = FakeView()
    api = FakeExperimentApi()

    _presenter(view, api).handle_set_initial_weight()

    assert view.ensure_calls == 1
    assert api.manual_initial_weight_called is True
    assert view.status_messages[-1] == "初始重量设置成功，已启用失重计算"
