"""Infrastructure adapters and repositories."""

